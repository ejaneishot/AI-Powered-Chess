# AI-Powered-Offline-Chess
My final project for my Algorithm and Programming course, where I made AI-powered chess solely with Python.

Instructions :
1. Download all the files, or download the folder then extract the files
2. Make sure to have all the codes in a folder called 'Chess'
3. In the folder there should be 3 python files and 1 folder called 'chess/images'
4. The folder should be Chess/ chessmain.py, ChessEngine.py, ChessAI.py, Chess/Images (the folder)
5. Run the the chessmain.py file, and the program should be working

How to play :
Simply click the pieces you want to move, there should be highlighted spots on where you can move that specific piece.
Press 'Z' in your keyboard to undo a move

Enjoy playing chess !
